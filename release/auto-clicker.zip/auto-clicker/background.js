chrome.runtime.onInstalled.addListener(() => {
  console.log("Auto Button Clicker Erweiterung installiert");
});
